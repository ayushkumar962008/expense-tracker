export type TransactionType="income"|"expense";
export type Transaction={id:string;description:string;category:string;amount:number;type:TransactionType;occurredAt:string};
export const categories=["Housing","Food & Dining","Transport","Tech & SaaS","Investments","Salary","Freelance","Other"];