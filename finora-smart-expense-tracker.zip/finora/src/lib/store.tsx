"use client";
import { createContext,useCallback,useContext,useEffect,useMemo,useState } from "react";
import type { Transaction } from "./types";
const T="finora.transactions",U="finora.user";
type Store={ready:boolean;user:string|null;signIn:(e:string)=>void;signOut:()=>void;transactions:Transaction[];addTransaction:(t:Omit<Transaction,"id">)=>void;updateTransaction:(t:Transaction)=>void;deleteTransaction:(id:string)=>void};
const C=createContext<Store|null>(null);
function read<X>(k:string,f:X):X{if(typeof window==="undefined")return f;try{const v=localStorage.getItem(k);return v?JSON.parse(v):f}catch{return f}}
export function StoreProvider({children}:{children:React.ReactNode}){const[ready,setReady]=useState(false);const[user,setUser]=useState<string|null>(null);const[transactions,setTransactions]=useState<Transaction[]>([]);
useEffect(()=>{setUser(read<string|null>(U,null));setTransactions(read<Transaction[]>(T,[{id:"1",description:"Monthly salary",category:"Salary",amount:85000,type:"income",occurredAt:new Date().toISOString()},{id:"2",description:"Groceries",category:"Food & Dining",amount:3200,type:"expense",occurredAt:new Date().toISOString()},{id:"3",description:"Internet bill",category:"Tech & SaaS",amount:1200,type:"expense",occurredAt:new Date().toISOString()}]));setReady(true)},[]);
const persist=useCallback((n:Transaction[])=>{setTransactions(n);localStorage.setItem(T,JSON.stringify(n))},[]);
const value=useMemo<Store>(()=>({ready,user,signIn:e=>{localStorage.setItem(U,JSON.stringify(e));setUser(e)},signOut:()=>{localStorage.removeItem(U);setUser(null)},transactions,addTransaction:t=>persist([{...t,id:crypto.randomUUID()},...transactions]),updateTransaction:t=>persist(transactions.map(x=>x.id===t.id?t:x)),deleteTransaction:id=>persist(transactions.filter(x=>x.id!==id))}),[ready,user,transactions,persist]);
return<C.Provider value={value}>{children}</C.Provider>}
export function useStore(){const x=useContext(C);if(!x)throw new Error("StoreProvider missing");return x}
export function formatINR(n:number){return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n)}