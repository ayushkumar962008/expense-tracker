"use client";
import { useEffect,useState } from "react";
import { useRouter } from "next/navigation";
import { Sidebar } from "./Sidebar";
import { TopBar } from "./TopBar";
import { TransactionFormModal } from "@/components/TransactionFormModal";
import { useStore } from "@/lib/store";
import type { Transaction } from "@/lib/types";
export function DashboardLayout({children}:{children:React.ReactNode}){const router=useRouter();const{ready,user,signOut}=useStore();const[nav,setNav]=useState(false);const[open,setOpen]=useState(false);const[editing,setEditing]=useState<Transaction|null>(null);
useEffect(()=>{if(ready&&!user)router.replace("/login")},[ready,user,router]);
if(!ready||!user)return(<div className="flex min-h-screen items-center justify-center bg-surface-container-lowest"><p className="font-body-md text-body-md text-on-surface-variant">Loading Finora…</p></div>);
return(<div className="min-h-screen bg-surface-container-lowest"><Sidebar open={nav} onClose={()=>setNav(false)} onSignOut={()=>{signOut();router.replace("/login")}}/><TopBar onMenuClick={()=>setNav(true)} onAddTransaction={()=>{setEditing(null);setOpen(true)}}/><div className="lg:pl-64">{children}</div><TransactionFormModal open={open} onClose={()=>setOpen(false)} editing={editing}/></div>)}