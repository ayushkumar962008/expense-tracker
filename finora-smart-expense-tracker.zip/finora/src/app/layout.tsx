import type { Metadata } from "next";
import { Inter, Plus_Jakarta_Sans } from "next/font/google";
import { StoreProvider } from "@/lib/store";
import "./globals.css";
const inter=Inter({subsets:["latin"],variable:"--font-inter",display:"swap"});
const jakarta=Plus_Jakarta_Sans({subsets:["latin"],variable:"--font-jakarta",display:"swap"});
export const metadata:Metadata={title:"Finora — Smart Expense Tracker",description:"Track income, expenses, and reports in INR."};
export default function RootLayout({children}:{children:React.ReactNode}){return(<html lang="en" className={`dark ${inter.variable} ${jakarta.variable}`}><head><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"/></head><body className="bg-surface-container-lowest font-body-md text-on-surface antialiased"><StoreProvider>{children}</StoreProvider></body></html>)}